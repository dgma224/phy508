g++ full_nl_pndlm.cpp -o nl_pendulum
g++ smpl_pndlm.cpp -o simple_pendulum

