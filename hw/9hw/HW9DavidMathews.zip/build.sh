g++ ising_met_hw.cpp -o ising
