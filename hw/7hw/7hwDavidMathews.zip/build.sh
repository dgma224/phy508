g++ perc_hw.cpp -o perc_hw
