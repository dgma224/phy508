g++ smpl_pndlm.cpp -o simple_pendulum
