g++ latt_hw.cpp -o latt_hw
