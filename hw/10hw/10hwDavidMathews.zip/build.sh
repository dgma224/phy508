g++ ising_wolff_hw.cpp -o wolff
