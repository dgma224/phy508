g++ full_nl_pndlm.cpp -o nl_pendulum

